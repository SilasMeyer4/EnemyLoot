# EnemyLoot
**adds loot for killing enemies** 

Not all enemies drop loot yet. 


## Enemies that can drop loot 
- Bunker Spider 
- Masked Enemy
- Hoarding Bug

