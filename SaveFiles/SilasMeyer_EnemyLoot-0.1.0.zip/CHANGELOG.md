# EnemyLoot 0.1.0
- release version (includes loot for Bunker Spiders, Masked Enemies and Hoarder Bugs)