# EnemyLoot 0.3.0

### Adjustments
- the orange orb now gives unlimited stamina while it is active
- added Tool Tips
- white orb gets now localy deleted after all charges are used. Yes, the item still keeps existing for other players.

### New Content
- added Spoon (loot for killing a Butler). The item does not work 100% how I invision it yet. 
- added Black Orb (loot for killing a Maneater). The item does not work 100% how I invision it yet. 

### Fixes
- Black orb teleportation works now differently. Fixes issues like having rain inside the factory after a teleport or not being able to be hit by enemies.


# EnemyLoot 0.2.0

### Adjustments
- adjusted rotation of Spider Egg and Guilty Gear Strive Case
- randomized value of dropped masks
- increased value of Spider Egg

### New Content
- added White Orb (loot for killing a Snare Flea)
- added Black Orb (loot for killing a Bracken)
- added Orange Orb (loot for killing a Thumper)

### Fixes
- shows now in the BepInEx console the correct mod version
- added BepInEx as dependency on the mod webpage


# EnemyLoot 0.1.0
- release version (includes loot for Bunker Spiders, Masked Enemies and Hoarder Bugs)
