# EnemyLoot 0.2.0

### Adjustments
- adjusted rotation of Spider Egg and Guilty Gear Strive Case
- randomized value of dropped masks
- increased value of Spider Egg

### New Content
- added White Orb (loot for killing a Snare Flea)
- added Black Orb (loot for killing a Bracken)
- added Orange Orb (loot for killing a Thumper)

### Fixes
- shows now in the BepInEx console the correct mod version
- added BepInEx as dependency on the mod webpage


# EnemyLoot 0.1.0
- release version (includes loot for Bunker Spiders, Masked Enemies and Hoarder Bugs)
